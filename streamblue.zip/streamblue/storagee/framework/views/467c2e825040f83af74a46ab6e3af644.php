

    <link rel="stylesheet" href="cantik/c-login.css">

<body>
    <main>
        <header>
            <div class="logo">
                <img src="<?php echo e(asset('gambar/logo.jpeg')); ?>">
            </div>
        </header>
        <div class="container">
            <div class="row">
                <div class="col-md-5">
                    <div class="card card-header">Login Your Account</div>
                    <div class="card-body">
                        <form action="<?php echo e(route('login')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="mb-4">
                                <label for="mail" class="form-label">Email</label>
                                <input type="text" name="mail" id="mail" value="<?php echo e(old('mail')); ?>" class="form-control">
                                <?php $__errorArgs = ["mail"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger mt-2">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-4">
                                <label for="password" class="form-label">Password</label>
                                <input type="password" name="password" id="password" class="form-control">
                                <?php $__errorArgs = ["password"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger mt-2">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="create">
                                <button type="submit" class="btn btn-primary">Login</button>
                                    <div class="account">
                                        <a href="/regris" style="margin-left: 500px"><br>Create Account</a>
                                    </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </main>

    </body>

<?php /**PATH C:\Users\user\Documents\GitHub\pbwf\streamblue\resources\views/login.blade.php ENDPATH**/ ?>