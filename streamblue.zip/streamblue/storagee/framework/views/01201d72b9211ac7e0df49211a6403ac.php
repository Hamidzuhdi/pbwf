<?php $__env->startSection('content'); ?>
<h2>Data User</h2>
<table border="1" style="border-collapse: collapse;">
    <thead>
        <tr>
            <th style="padding-right: 50px;">ID</th>
            <th style="padding-right: 50px;">nama</th>
            <th style="padding-right: 50px;">email</th>
            <th style="padding-right: 50px;">role</th>
            <th style="padding-right: 50px;">telepon</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td style="padding-right: 50px;"><?php echo e($user->id); ?></td>
                <td style="padding-right: 50px;"><?php echo e($user->nama); ?></td>
                <td style="padding-right: 50px;"><?php echo e($user->mail); ?></td>
                <td style="padding-right: 50px;"><?php echo e($user->role); ?></td>
                <td style="padding-right: 50px;"><?php echo e($user->telp); ?></td>
                <td>
                    <a href="/admin/modal/edituser/<?php echo e($user->id); ?>/edit">edit</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\GitHub\pbwf\streamblue\resources\views/admin/page/auser.blade.php ENDPATH**/ ?>