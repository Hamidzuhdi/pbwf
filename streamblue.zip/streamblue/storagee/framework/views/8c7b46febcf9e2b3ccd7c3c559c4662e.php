<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Edit Data user</title>
</head>
<body>
    <h1>Data user</h1>

    <?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<form action="/admin/modal/edituser/<?php echo e($user->id); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>

    <label for="nama">nama:</label>
    <input type="text" name="nama" id="nama" value="<?php echo e($user->nama); ?>" required>
    <br><br>

    <label for="mail">mail:</label>
    <input type="text" name="mail" id="mail" value="<?php echo e($user->mail); ?>" required>
    <br><br>

    <label for="role">role:</label>
    <select name="role" id="role" required>
        <option value="admin" <?php echo e($user->role === 'admin' ? 'selected' : ''); ?>>Admin</option>
        <option value="customer" <?php echo e($user->role === 'customer' ? 'selected' : ''); ?>>Customer</option>
        <option value="superadmin" <?php echo e($user->role === 'superadmin' ? 'selected' : ''); ?>>superadmin</option>
    </select>
    <br><br>

    <label for="telp">telp:</label>
    <input type="text" name="telp" id="telp" value="<?php echo e($user->telp); ?>" required>
    <br><br>
    <button type="submit">Update</button>
</form>

</body>
</html>
<?php /**PATH C:\Users\user\Documents\GitHub\pbwf\streamblue\resources\views//admin/modal/edituser.blade.php ENDPATH**/ ?>