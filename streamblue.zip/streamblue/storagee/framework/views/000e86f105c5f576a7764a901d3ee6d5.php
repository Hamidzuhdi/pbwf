<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Edit Data Langganan</title>
</head>
<body>
    <h1>Data Langganan</h1>

    <?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<form action="/admin/modal/editlangganan/<?php echo e($langganan->id); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>

    <label for="ket">Keterangan:</label>
    <input type="text" name="ket" id="ket" value="<?php echo e($langganan->ket); ?>" required>
    <br><br>

    <label for="gambar">gambar:</label>
    <input type="file" name="gambar" id="gambar" value="<?php echo e($langganan->gambar); ?>" required>
    <br><br>

    <label for="harga">Harga:</label>
    <input type="number" name="harga" id="harga" value="<?php echo e($langganan->harga); ?>" required>
    <br><br>

    <button type="submit">Update</button>
</form>

</body>
</html>
<?php /**PATH C:\Users\user\Documents\GitHub\pbwf\streamblue\resources\views//admin/modal/editlangganan.blade.php ENDPATH**/ ?>