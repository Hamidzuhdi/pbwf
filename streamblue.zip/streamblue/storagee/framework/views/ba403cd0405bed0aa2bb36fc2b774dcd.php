<?php $__env->startSection('content'); ?>
<h2>Data Pemesanan</h2>
<table border="1" style="border-collapse: collapse;">
    <thead>
        <tr>
            <th style="padding-right: 30px;">ID</th>
            <th style="padding-right: 30px;">Total Harga</th>
            <th style="padding-right: 30px;">Durasi</th>
            <th style="padding-right: 30px;">User Id </th>
            <th style="padding-right: 30px;">Langganan ID</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $pemesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pemesanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td style="padding-right: 30px;"><?php echo e($pemesanan->id); ?></td>
                <td style="padding-right: 30px;"><?php echo e($pemesanan->total_harga); ?></td>
                <td style="padding-right: 30px;"><?php echo e($pemesanan->durasi); ?></td>
                <td style="padding-right: 30px;"><?php echo e($pemesanan->user_id); ?></td>
                <td style="padding-right: 30px;"><?php echo e($pemesanan->langganan_id); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\GitHub\pbwf\streamblue\resources\views//admin/page/apemesanan.blade.php ENDPATH**/ ?>