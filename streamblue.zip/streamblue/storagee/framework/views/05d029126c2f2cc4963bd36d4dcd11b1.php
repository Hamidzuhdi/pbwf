<?php $__env->startSection('sambung'); ?>
    <h1>halo</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('hubung.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\streamblue\resources\views/rumah.blade.php ENDPATH**/ ?>