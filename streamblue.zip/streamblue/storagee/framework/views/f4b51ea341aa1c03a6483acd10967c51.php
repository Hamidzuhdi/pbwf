<?php $__env->startSection('content'); ?>
<h2>Data pembayaran</h2>
<table border="1" style="border-collapse: collapse;">
    <thead>
        <tr>
            <th style="padding-right: 30px;">ID</th>
            <th style="padding-right: 30px;">Total bayar</th>
            <th style="padding-right: 30px;">Pemesanan Id</th>
            <th style="padding-right: 30px;">Gambar</th>
            <th style="padding-right: 30px;">Status</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $pembayarans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pembayaran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td style="padding-right: 30px;"><?php echo e($pembayaran->id); ?></td>
                <td style="padding-right: 30px;"><?php echo e($pembayaran->total_bayar); ?></td>
                <td style="padding-right: 30px;"><?php echo e($pembayaran->pemesanan_id); ?></td>
                <td style="padding-right: 80px;">
                    <img src="<?php echo e(asset('storage/gambar/' . $pembayaran->gambar)); ?>" style="width: 100px; height: auto;" alt="gambar">
                </td>
                <td style="padding-right: 30px;"><?php echo e($pembayaran->status); ?></td>
                <td>
                    <a href="/pembayaran/resetspb/<?php echo e($pembayaran->id); ?>" class="btn btn-danger btn-sm">
                        <i class="bi bi-cart-check-fill"></i>
                    </a>
                </td>
                <td>
                    <a href="/pembayaran/resetspg/<?php echo e($pembayaran->id); ?>" class="btn btn-danger btn-sm">
                        <i class="bi bi-bag-x"></i>
                    </a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\GitHub\pbwf\streamblue\resources\views//admin/page/apembayaran.blade.php ENDPATH**/ ?>