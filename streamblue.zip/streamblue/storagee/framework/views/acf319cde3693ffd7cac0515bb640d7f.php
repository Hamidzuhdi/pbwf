<?php $__env->startSection('css1'); ?>
     <!-- Bootstrap icons-->
     <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" type="text/css" />
     <!-- Google fonts-->
     <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css" />
     <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.15.0/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="cantik/c-live.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sambung'); ?>
<body>
    
    <?php $__currentLoopData = $pertandingans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pertandingan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($pertandingan->liga == 'epl'): ?>
        <div>
            <h6 class="liga"><?php echo e($pertandingan->liga); ?></h6>
        </div>
            <div class="Bungkus">
                <div class="Pertama">
                    <p class="tgl_pertandingan"><?php echo e($pertandingan->tgl_pertandingan); ?></p>
                    <br>
                </div>
                <div class="P-Dua">
                    <span class="nama_pertandingan"><?php echo e($pertandingan->nama_pertandingan); ?></span>
                    <br>
                </div>
                <div>
                    <a href="https://connect-id.beinsports.com/id">
                        <i class="bi bi-tv-fill"></i>
                    </a>
                </div>
            </div>
        <?php elseif($pertandingan->liga == 'ucl'): ?>
        <div>
            <h6 class="liga"><?php echo e($pertandingan->liga); ?></h6>
        </div>
            <div class="Bungkus">
                <div class="Pertama">
                    <p class="tgl_pertandingan"><?php echo e($pertandingan->tgl_pertandingan); ?></p>
                    <br>
                </div>
                <div class="P-Dua">
                    <span class="nama_pertandingan"><?php echo e($pertandingan->nama_pertandingan); ?></span>
                    <br>
                </div>
                <div>
                    <a href="https://connect-id.beinsports.com/id">
                        <i class="bi bi-tv-fill"></i>
                    </a>
                </div>
            </div>
        <?php elseif($pertandingan->liga == 'bundesliga'): ?>
        <div>
            <h6 class="liga"><?php echo e($pertandingan->liga); ?></h6>
        </div>
            <div class="Bungkus">
                <div class="Pertama">
                    <p class="tgl_pertandingan"><?php echo e($pertandingan->tgl_pertandingan); ?></p>
                    <br>
                </div>
                <div class="P-Dua">
                    <span class="nama_pertandingan"><?php echo e($pertandingan->nama_pertandingan); ?></span>
                    <br>
                </div>
                <div>
                    <a href="https://connect-id.beinsports.com/id">
                        <i class="bi bi-tv-fill"></i>
                    </a>
                </div>
            </div>
        <?php elseif($pertandingan->liga == 'seri A'): ?>
        <div>
            <h6 class="liga"><?php echo e($pertandingan->liga); ?></h6>
        </div>
            <div class="Bungkus">
                <div class="Pertama">
                    <p class="tgl_pertandingan"><?php echo e($pertandingan->tgl_pertandingan); ?></p>
                    <br>
                </div>
                <div class="P-Dua">
                    <span class="nama_pertandingan"><?php echo e($pertandingan->nama_pertandingan); ?></span>
                    <br>
                </div>
                <div>
                    <a href="https://connect-id.beinsports.com/id">
                        <i class="bi bi-tv-fill"></i>
                    </a>
                </div>
            </div>
            <?php elseif($pertandingan->liga == 'league one'): ?>
            <div>
                <h6 class="liga"><?php echo e($pertandingan->liga); ?></h6>
            </div>
                <div class="Bungkus">
                    <div class="Pertama">
                        <p class="tgl_pertandingan"><?php echo e($pertandingan->tgl_pertandingan); ?></p>
                        <br>
                    </div>
                    <div class="P-Dua">
                        <span class="nama_pertandingan"><?php echo e($pertandingan->nama_pertandingan); ?></span>
                        <br>
                    </div>
                    <div>
                        <a href="https://connect-id.beinsports.com/id">
                            <i class="bi bi-tv-fill"></i>
                        </a>
                    </div>
                </div>
                <?php endif; ?>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('hubung.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\GitHub\pbwf\streamblue\resources\views/live.blade.php ENDPATH**/ ?>