<?php $__env->startSection('css2'); ?>
    <link rel="stylesheet" href="cantik/c-regris.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sambung'); ?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="cantik/c-regris.css">
    <title>Registrasi Pemain Sepak Bola</title>
</head>
<body>
    <div class="container">
        <h1>Registrasi Pemain Sepak Bola</h1>
         <form action="/regris" method="post">
             <?php echo csrf_field(); ?>
             <div class="petot" data-user-id="<?php echo e($user->id ?? ''); ?>">
                <!-- Konten petot lainnya -->
            </div>
            <div class="mb-4">
                <label for="nama" class="form-label" style="background-color: whitesmoke">Username</label>
                <input type="text" name="nama" id="nama" class="form-control">
                <?php $__errorArgs = ["nama"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger mt-2">
                        <?php echo e($message); ?>

                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-4">
                <label for="mail" class="form-label" style="background-color: whitesmoke">Email</label>
                <input type="text" name="mail" id="mail" class="form-control">
                <?php $__errorArgs = ["mail"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger mt-2">
                        <?php echo e($message); ?>

                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="mb-4" style="display: none;">
                    <label for="role" class="form-label" style="background-color: whitesmoke">Role</label>
                    <select name="role" id="role" class="form-select">
                        <option value="customer">Customer</option>
                        <option value="admin">Admin</option>
                    </select>
                    <?php $__errorArgs = ["role"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger mt-2">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            <div class="mb-4">
                <label for="telp" class="form-label" style="background-color: whitesmoke">Telp</label>
                <input type="text" name="telp" id="telp" class="form-control">
                <?php $__errorArgs = ["telp"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger mt-2">
                        <?php echo e($message); ?>

                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-4">
                <label for="password" class="form-label" style="background-color: whitesmoke">Password</label>
                <input type="password" name="password" id="password" class="form-control">
                <?php $__errorArgs = ["password"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger mt-2">
                        <?php echo e($message); ?>

                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <button type="submit" class="btn btn-primary">Sign in</button>
        </form>
        <p style="margin-top: 20px;">Already have an account? <a href="<?php echo e(route('login')); ?>">Login here</a></p>
    </div>
</body>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        // Temukan semua elemen card
        const petots = document.querySelectorAll(".petot");

        // Tambahkan event click ke setiap petot
        petots.forEach(petot => {
            petot.addEventListener("click", function() {
                const userId = petot.getAttribute("data-user-id");
            });
        });
    });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('hubung.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\GitHub\pbwf\streamblue\resources\views/regris.blade.php ENDPATH**/ ?>