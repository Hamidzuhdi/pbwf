<?php $__env->startSection('css3'); ?>
         <!-- Bootstrap icons-->
         <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" type="text/css" />
         <!-- Google fonts-->
         <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css" />
         <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.15.0/font/bootstrap-icons.css" rel="stylesheet">
        <link rel="stylesheet" href="cantik/c-jadwal.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sambung'); ?>

<h1>Jadwal Pertandingan Sepak Bola</h1>

<?php $__currentLoopData = $pertandingans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pertandingan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="match">
        <p class="tgl_pertandingan"><?php echo e($pertandingan->tgl_pertandingan); ?></p>
        <div class="team">
            <span class="nama_pertandingan"><?php echo e($pertandingan->nama_pertandingan); ?></span>
        </div>
        <p>Stadion: Stadion Utama</p>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('hubung.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\GitHub\pbwf\streamblue\resources\views/jadwal.blade.php ENDPATH**/ ?>