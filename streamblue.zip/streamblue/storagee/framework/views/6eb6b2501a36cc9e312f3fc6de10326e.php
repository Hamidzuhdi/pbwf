<?php $__env->startSection('content'); ?>
<table border="1">
    <thead>
        <tr>
            <th>ID</th>
            <th>Tanggal Pertandingan</th>
            <th>Nama Pertandingan</th>
            <th>Liga</th>
            <th>Langganan ID</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $pertandingans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pertandingan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($pertandingan->id); ?></td>
                <td><?php echo e($pertandingan->tgl_pertandingan); ?></td>
                <td><?php echo e($pertandingan->nama_pertandingan); ?></td>
                <td><?php echo e($pertandingan->liga); ?></td>
                <td><?php echo e($pertandingan->langganan_id); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\GitHub\pbwf\streamblue\resources\views/admin/page/apertandingan.blade.php ENDPATH**/ ?>