<?php $__env->startSection('content'); ?>
<h2>Data Pertandingan</h2>
<table border="1" style="border-collapse: collapse;">
    <thead>
        <tr>
            <th style="padding-right: 30px;">ID</th>
            <th style="padding-right: 30px;">Tanggal Pertandingan</th>
            <th style="padding-right: 30px;">Nama Pertandingan</th>
            <th style="padding-right: 30px;">Liga</th>
            <th style="padding-right: 30px;">Langganan ID</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $pertandingans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pertandingan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td style="padding-right: 30px;"><?php echo e($pertandingan->id); ?></td>
                <td style="padding-right: 30px;"><?php echo e($pertandingan->tgl_pertandingan); ?></td>
                <td style="padding-right: 30px;"><?php echo e($pertandingan->nama_pertandingan); ?></td>
                <td style="padding-right: 30px;"><?php echo e($pertandingan->liga); ?></td>
                <td style="padding-right: 30px;"><?php echo e($pertandingan->langganan_id); ?></td>
                <td>
                    <a href="/admin/modal/editpertandingan/<?php echo e($pertandingan->id); ?>/edit">edit</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<a href="/admin/modal/addpertandingan" class="btn btn-sm btn-success" style="margin-top: 20px">Tambah Pertandingan Baru</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\GitHub\pbwf\streamblue\resources\views//admin/page/apertandingan.blade.php ENDPATH**/ ?>