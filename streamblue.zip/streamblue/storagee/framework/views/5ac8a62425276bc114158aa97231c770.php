<?php $__env->startSection('content'); ?>
<h2>Data Langganan</h2>
<table border="1" style="border-collapse: collapse;">
    <thead>
        <tr>
            <th style="padding-right: 80px;">ID</th>
            <th style="padding-right: 80px;">keterangan</th>
            <th style="padding-right: 80px;">gambar</th>
            <th style="padding-right: 80px;">harga</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $langganans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $langganan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td style="padding-right: 80px;"><?php echo e($langganan->id); ?></td>
                <td style="padding-right: 80px;"><?php echo e($langganan->ket); ?></td>
                <td style="padding-right: 80px;">
                    <img src="<?php echo e(asset('gambar/' . $langganan->gambar)); ?>" style="width: 100px; height: auto;" alt="Langganan Image">
                </td>
                <td style="padding-right: 80px;"><?php echo e($langganan->harga); ?></td>
                <td>
                    <a href="/admin/modal/editlangganan/<?php echo e($langganan->id); ?>/edit">edit</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<a href="/admin/modal/addlangganan" class="btn btn-sm btn-success" style="margin-top: 20px">Tambah langganan Baru</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Documents\GitHub\pbwf\streamblue\resources\views//admin/page/alangganan.blade.php ENDPATH**/ ?>