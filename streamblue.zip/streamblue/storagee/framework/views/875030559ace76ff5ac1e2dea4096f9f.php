<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Langganan</title>
    <link rel="stylesheet" href="cantik/c-langganan.css">
</head>
<body>
    <div class="pilih">
        <p>user id <?php echo e($userId); ?></p>
        <div class="halow" data-user-id=<?php echo e($userId); ?>></div>
    <?php $__currentLoopData = $langganans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $langganan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card">
            <div class="card-body" data-langganan-id=<?php echo e($langganan->id); ?> >
                <p class="m-0"><?php echo e($langganan->ket); ?> <?php echo e($langganan->tipe ? '+ UCL' : '- UCL'); ?></p>
            </div>
            <div class="card-header">
                <a href="/pemesanan?langgananId=<?php echo e($langganan->id); ?>&userId=<?php echo e($userId); ?>&langgananGambar=<?php echo e($langganan->gambar); ?>&langgananharga=<?php echo e($langganan->harga); ?>">
                    <!-- Tambahkan atribut data dengan nilai gambar langganan -->
                    <img src="<?php echo e(asset('gambar/' . $langganan->gambar)); ?>" data-langganan-gambar="<?php echo e($langganan->gambar); ?>" alt="<?php echo e($langganan->gambar); ?>" class="gambar-langganan">
                </a>
            </div>
            <div class="card-footer" data-langganan-harga="<?php echo e($langganan->harga); ?>">
                <p class="m-0"><?php echo e($langganan->harga); ?> / bulan</p>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</body>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        // Temukan semua elemen card
        const pilihs = document.querySelectorAll(".pilih");

        // Tambahkan event click ke setiap pilih
        pilihs.forEach(pilih => {
            pilih.addEventListener("click", function() {
                // Dapatkan data langganan dan gambar dari pilih yang dipilih
                const langgananId = pilih.querySelector(".pilih-body").getAttribute("data-langganan-id");
                const userId = pilih.querySelector(".halow").getAttribute("data-user-id");
                const langgananGambar = pilih.querySelector(".gambar-langganan").getAttribute("data-langganan-gambar");
                const langgananharga = pilih.querySelector(".card .card-footer").getAttribute("data-langganan-harga");

                // Arahkan pengguna ke halaman pemesanan dengan data yang dipilih
                window.location.href = `/pemesanan?langgananId=${langgananId}&langgananGambar=${langgananGambar}&langgananharga=${langgananharga}`;
            });
        });
    });
    </script>
    </html>


</html>
<?php /**PATH C:\Users\user\Documents\GitHub\pbwf\streamblue\resources\views/langganan.blade.php ENDPATH**/ ?>